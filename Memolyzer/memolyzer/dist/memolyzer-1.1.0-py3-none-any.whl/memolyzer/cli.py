import argparse
parser = argparse.ArgumentParser(
    prog="Memolyzer",
    description="Tasking Compiler Compitable Memory Analyzer",
    epilog="Your analysis is done, Thanks for using %(prog)s :) "
)
parser.add_argument("--mapfile", help="path of map file for processing",
                    type=str)
parser.add_argument("--mode", choices=["symbol","overall"])
parser.add_argument("--output", choices=["csv","xlsx"], default="store_false")
args = parser.parse_args()
print(args.mapfile)

