
import regex as re
from prettytable import PrettyTable 
import pandas as pd

class MapFileTable():
    table_border_pattern = re.compile(r"[\+]+\-+\+$")

    def __init__(self) -> None:
        pass
    
    def get_table_from_txt(self, lines, header_pattern_statement):
        table_founded = False
        rows = list()
        header_pattern = re.compile(header_pattern_statement)
        header_found = False
        for line in lines:
            header_obj = re.search(header_pattern,line)            
            if(header_obj):
                header_found = True
                continue
        
            if header_found:
                if not table_founded:
                    table_border_obj = re.search(self.table_border_pattern,line)
                    if(table_border_obj):
                        table_founded = True
                        continue
                if table_founded:
                    table_border_obj = re.search(self.table_border_pattern,line)
                    
                    if(table_border_obj):
                        table_founded = False
                        break

                    if line.startswith("|") :
                        row =[ i.rstrip().lstrip() for i in line.split("|")[1:-1] ]  # İlk ve son boş sütunları atla
                        if len(row)>1: rows.append(row) 
        return rows

    def convert_to_pretty_table(self, rows):
        table = PrettyTable(rows[0])
        for row in rows[1:]:
            table.add_row(row)
        return table

    def convert_to_data_frame(self, rows):
        df = pd.DataFrame(rows)
        new_header = df.iloc[0] #grab the first row for the header
        df = df[1:] #take the data less the header row
        df.columns = new_header #set the header row as the df header
        return df
    
    def save_df_as_html(self,df,name='temp.html'):
        text_file = open(name, "w")
        text_file.write(df.to_html())
        text_file.close()
    
