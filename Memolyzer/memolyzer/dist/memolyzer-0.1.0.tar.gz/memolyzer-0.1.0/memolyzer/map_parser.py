
import regex as re
import os
from pathlib import Path
from prettytable import PrettyTable 
from memolyzer.table import MapFileTable 

def read_file_line_by_line(file):
    try:
        f = open(file, "r")
        lines = f.readlines()
        f.close()
        return lines
    except Exception:
        print("Could not read to file")

def read_file_as_str(file):
    try:
        f = open(file, "r")
        txt = ""
        for line in f.readlines():
            txt = txt + line 
        f.close()
        return txt
    except Exception:
        print("Could not read to file")





PROCESSED_FILES = "/^[\*]+\s*Processed Files\s*[\*]+$/"
LINK_RESULTS = "/^[\*]+\s*Link Result\s*[\*]+$/"
LOCATE_RESULTS = "/^[\*]+\s*Locate Result\s*[\*]+$/"
USED_RESOURCES = "/^[\*]+\s*Used Resources\s*[\*]+$/"
UNKNOWN = "/^[\*]* .* [\*]*$/"

MAP_FILE_NAME = "CEER_VCU_APP_V1_B_1.elf.map"
MAP_FILE_PATH = os.path.normpath(os.path.join(Path(__file__).parent.absolute(),os.pardir,"example-data",MAP_FILE_NAME))

class MapParser:
    def __init__(self, map_file_path) -> None:
        self.map_file_path = map_file_path
        self.map_file = read_file_line_by_line(self.map_file_path)
        self.headers = list(dict())
        self.headers = self.get_file_parts()
        self.tables = {}
        # self.tables = {
        #     "Overall": self.get_overall(),
        #     "Symbols": self.get_symbols_by_adress(),
        #     "Locate Result Sections": self.get_locate_results_sections(),          
        # }
    
    def main(self):
        pass

    def load():
        pass

    def get_file_parts(self):
        
        header_pattern = re.compile(r"^[\*]+\s*(?P<header>[a-zA-Z0-9 ]+)\s*[\*]+$")

        for line in self.map_file:
            header_match_object =  re.search(header_pattern, line)
            if(header_match_object):
                header = {"title":header_match_object.group('header').rstrip(),
                          "start_line": self.map_file.index(line),
                          "end_line"  : len(self.map_file)
                          }
                self.headers.append(header)
                if self.headers:
                    self.headers[self.headers.index(header)-1]["end_line"] = self.map_file.index(line) - 1
                    
        return self.headers
    
    def get_header_info(self, header):
        for head in self.headers:
            if(head["title"] == header):
                return head
        return None

    def get_symbols_by_adress(self):
        start_line = self.get_header_info("Locate Result")["start_line"]        
        end_line = self.get_header_info("Locate Result")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"\* Symbols \(sorted on address\)")
        table = MapFileTable().convert_to_pretty_table(rows)
        return table

    def get_symbols_by_name(self):
        start_line = self.get_header_info("Locate Result")["start_line"]        
        end_line = self.get_header_info("Locate Result")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"\* Symbols \(sorted on name\)")
        table = MapFileTable().convert_to_pretty_table(rows)
        return table
    
    def get_overall(self):
        start_line = self.get_header_info("Used Resources")["start_line"]        
        end_line = self.get_header_info("Used Resources")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"\* Memory usage in bytes")
        #base_table = MapFileTable().convert_to_pretty_table(rows)
        base_table = MapFileTable().convert_to_data_frame(rows)
        
        #memory usage percentages
        percentage =  [(int(total,16)-int(free,16)) / int(total,16) * 100
                       for free,total in zip(base_table['Free'],base_table['Total'])]         
        base_table['Overall'] = percentage
        return base_table

    def get_locate_results_sections(self):
        start_line = self.get_header_info("Locate Result")["start_line"]        
        end_line = self.get_header_info("Locate Result")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"\* Sections")
        table = MapFileTable().convert_to_data_frame(rows)
        return table
    
    def get_cross_referenfes(self):
        start_line = self.get_header_info("Cross References")["start_line"]        
        end_line = self.get_header_info("Cross References")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"[\*]+\s*Cross References\s*[\*]+")
        table = MapFileTable().convert_to_data_frame(rows)
        return table
    
    def get_link_result(self):
        start_line = self.get_header_info("Link Result")["start_line"]        
        end_line = self.get_header_info("Link Result")["end_line"]
        lines = self.map_file[start_line:end_line]
        rows = MapFileTable().get_table_from_txt(lines,r"[\*]+\s*Link Result\s*[\*]+")
        table = MapFileTable().convert_to_data_frame(rows)
        return table
    
    def get_symbol_info(self, symbol_name):
        pass
    
    
    def get_overview_of_map_file(self):
        """_summary_: This function should return a dictionary that show all
        of the Tables in the Map file structure. For ex.
        {
            Used Resources:{
                Table1,
                Table2,
                ...
            }
            Locate Result{
                Table1,
                Table2,
                ...
            }
        }
        """
            

print("serkan")


